import mysql.connector
mydb=mysql.connector.connect(host="localhost",user="root",password="",database="project_allocation");
mycursor=mydb.cursor();
try:
    mycursor.execute("create table proj_reg(pid int(10) primary key,pname varchar(30),pdesc varchar(3),pduration int(3),pskills varchar(10),assign_to int(20))")
    print("table created")
except Exception as e:
    print("can not process",e)