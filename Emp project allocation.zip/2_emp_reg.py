import mysql.connector
mydb=mysql.connector.connect(host="localhost",user="root",password="",database="project_allocation");
mycursor=mydb.cursor();
try:
    mycursor.execute("create table emp_reg(eid int(10) primary key,ename varchar(30),email varchar(20),mobile int(10),designation varchar(20),address varchar(30),exp_year varchar(10),BOD varchar(10),add_id int(12),passport varchar(20),skills varchar(30),pid int(20),p_status varchar(20),p_sub_date varchar(20))")
    print("table created")
except Exception as e:
    print("can not process",e)